export type PaymentSettings = {
  phone_number: string;
  account_name: string;
  amount: number;
  logo_url: string | null;
  account_label: string;
  whatsapp_link: string;
};

const BACKEND_URL =
  import.meta.env.VITE_SUPABASE_URL || "https://ivvfdxrfqmboovlvczzs.supabase.co";

const PUBLISHABLE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml2dmZkeHJmcW1ib292bHZjenpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcxMzA4MjYsImV4cCI6MjA5MjcwNjgyNn0.XwVLanIDLqxis6XTgLqRS74JkqlsrA7z4UvJp6gCkgY";

export const fetchPaymentSettings = async (): Promise<PaymentSettings | null> => {
  const response = await fetch(
    `${BACKEND_URL}/rest/v1/payment_settings?select=phone_number,account_name,amount,logo_url,account_label,whatsapp_link&order=updated_at.desc,created_at.desc&limit=1`,
    {
      cache: "no-store",
      headers: {
        apikey: PUBLISHABLE_KEY,
        Authorization: `Bearer ${PUBLISHABLE_KEY}`,
        "Cache-Control": "no-cache",
        Pragma: "no-cache",
      },
    },
  );

  if (!response.ok) return null;

  const rows = (await response.json()) as PaymentSettings[];
  return rows[0] ?? null;
};
