CREATE POLICY "Anyone can update payment settings"
ON public.payment_settings
FOR UPDATE
USING (true)
WITH CHECK (true);