-- Storage bucket for payment screenshots
INSERT INTO storage.buckets (id, name, public)
VALUES ('payment-screenshots', 'payment-screenshots', true)
ON CONFLICT (id) DO NOTHING;

-- Public can read (so admin panel can preview via public URL)
CREATE POLICY "Public read payment screenshots"
ON storage.objects FOR SELECT
USING (bucket_id = 'payment-screenshots');

-- Anyone (anon) can upload screenshots
CREATE POLICY "Anyone can upload payment screenshots"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'payment-screenshots');

-- Table to track screenshots
CREATE TABLE public.payment_screenshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  storage_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  user_phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.payment_screenshots ENABLE ROW LEVEL SECURITY;

-- Anyone can insert a screenshot record (matches anonymous upload flow)
CREATE POLICY "Anyone can insert payment screenshot record"
ON public.payment_screenshots FOR INSERT
WITH CHECK (true);

-- Reading and deleting goes through admin edge functions using service role,
-- so no public SELECT/DELETE policy is needed.

CREATE INDEX idx_payment_screenshots_created_at
ON public.payment_screenshots (created_at DESC);