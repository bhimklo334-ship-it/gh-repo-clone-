ALTER TABLE public.payment_settings 
  ADD COLUMN IF NOT EXISTS logo_url text,
  ADD COLUMN IF NOT EXISTS account_label text NOT NULL DEFAULT 'JazzCash';