import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-admin-password",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const ADMIN_PASSWORD = Deno.env.get("ADMIN_PASSWORD");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!ADMIN_PASSWORD || !SUPABASE_URL || !SERVICE_ROLE) {
      return new Response(
        JSON.stringify({ error: "Server not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const provided = req.headers.get("x-admin-password");
    if (provided !== ADMIN_PASSWORD) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid JSON body" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const { phone_number, account_name, amount, logo_url, account_label, whatsapp_link } = body ?? {};

    const row: Record<string, unknown> = {};

    if (phone_number !== undefined) {
      if (typeof phone_number !== "string" || phone_number.trim().length === 0) {
        return new Response(
          JSON.stringify({ error: "Phone number cannot be empty" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      row.phone_number = phone_number.trim();
    }

    if (account_name !== undefined) {
      if (typeof account_name !== "string" || account_name.trim().length === 0) {
        return new Response(
          JSON.stringify({ error: "Account name cannot be empty" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      row.account_name = account_name.trim();
    }

    if (amount !== undefined) {
      const amountNum = Number(amount);
      if (!Number.isFinite(amountNum) || amountNum < 0) {
        return new Response(
          JSON.stringify({ error: "Amount must be a positive number" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      row.amount = Math.round(amountNum);
    }

    if (account_label !== undefined) {
      const labelTrim = typeof account_label === "string" ? account_label.trim() : "";
      row.account_label = labelTrim.length > 0 ? labelTrim : "JazzCash";
    }

    if (logo_url === null) {
      row.logo_url = null;
    } else if (typeof logo_url === "string") {
      if (logo_url.length > 2_000_000) {
        return new Response(
          JSON.stringify({ error: "Logo image too large (max ~1.5MB). Please compress it." }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      row.logo_url = logo_url;
    }

    if (typeof whatsapp_link === "string") {
      row.whatsapp_link = whatsapp_link.trim();
    }

    if (Object.keys(row).length === 0) {
      return new Response(
        JSON.stringify({ error: "No fields provided to update" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);
    row.updated_at = new Date().toISOString();

    const { data: existing, error: selErr } = await supabase
      .from("payment_settings")
      .select("id")
      .order("updated_at", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (selErr) throw selErr;

    if (existing?.id) {
      const { error } = await supabase
        .from("payment_settings")
        .update(row)
        .eq("id", existing.id);
      if (error) throw error;
    } else {
      if (!row.phone_number) row.phone_number = "";
      if (!row.account_name) row.account_name = "";
      if (row.amount === undefined) row.amount = 0;
      const { error } = await supabase
        .from("payment_settings")
        .insert(row);
      if (error) throw error;
    }

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error("update-payment-settings error:", e);
    const msg = e instanceof Error && e.message
      ? e.message
      : (typeof e === "string" ? e : JSON.stringify(e));
    return new Response(
      JSON.stringify({ error: msg || "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
