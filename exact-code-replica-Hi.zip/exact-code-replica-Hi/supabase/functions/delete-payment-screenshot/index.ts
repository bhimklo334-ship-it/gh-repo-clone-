import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-admin-password",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const ADMIN_PASSWORD = Deno.env.get("ADMIN_PASSWORD");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!ADMIN_PASSWORD || !SUPABASE_URL || !SERVICE_ROLE) {
      return new Response(JSON.stringify({ error: "Server not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (req.headers.get("x-admin-password") !== ADMIN_PASSWORD) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const { id, deleteAll } = body ?? {};

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

    if (deleteAll === true) {
      const { data: rows, error: selErr } = await supabase
        .from("payment_screenshots")
        .select("id, storage_path");
      if (selErr) throw selErr;

      const paths = (rows ?? []).map((r) => r.storage_path).filter(Boolean);
      if (paths.length > 0) {
        await supabase.storage.from("payment-screenshots").remove(paths);
      }
      const { error: delErr } = await supabase
        .from("payment_screenshots")
        .delete()
        .not("id", "is", null);
      if (delErr) throw delErr;

      return new Response(JSON.stringify({ success: true, deleted: paths.length }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (typeof id !== "string" || id.length === 0) {
      return new Response(JSON.stringify({ error: "Invalid id" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: row, error: getErr } = await supabase
      .from("payment_screenshots")
      .select("storage_path")
      .eq("id", id)
      .maybeSingle();
    if (getErr) throw getErr;

    if (row?.storage_path) {
      await supabase.storage.from("payment-screenshots").remove([row.storage_path]);
    }

    const { error: delErr } = await supabase
      .from("payment_screenshots")
      .delete()
      .eq("id", id);
    if (delErr) throw delErr;

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
