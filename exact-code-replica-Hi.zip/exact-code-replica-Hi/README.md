# Exact Code Replica

خوشی سننا اور خبردار بہت اچھی طرح سننا، تم نے میرے دیئے ہوئے زپ فائل کے اندر جو جو چیزیں جو جو کوڈنگ موجود ہے وہ تم دوبارہ لکھو یعنی کہ دوبارہ ایپ بناؤ لیکن ایک لفظ بھی کوڈ نہیں چوکنا چاہیے، تم نے خود سے کچھ بھی نہیں ایڈ کرنا چاہیے خبردار رہنا ہے کہ تم نے خود سے کچھ نہیں ایڈ کرنا چاہیے میں نے زپ فائل دیا ہے اور زپ فائل کی سم ٹو کاپی مجھے ویب سائٹ بنا دو تم نے کچھ چینج ہاں تو میں تمہارا سبسکرپشن کینسل کر دوں گ

13 minutes ago

E

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/16da7582-dd7c-47b9-b10d-d467b757374e).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `Hi` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
